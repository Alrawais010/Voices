package com.alrawais.sawtiyati;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Insets;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.webkit.JavascriptInterface;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int PICK_FILES = 1;
    private static final int PICK_FOLDER = 2;
    private static final int PICK_REPLACEMENT = 3;
    private static final String[] AUDIO_TYPES = {"audio/*", "application/ogg"};

    private final Handler handler = new Handler(Looper.getMainLooper());
    private WebView web;
    private String replaceId;
    private String lastState = "";
    private String insetsJs;

    private final Runnable stateTick = new Runnable() {
        @Override public void run() {
            pushState();
            handler.postDelayed(this, 300);
        }
    };

    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        Store.init(this);
        getWindow().setDecorFitsSystemWindows(false);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setTextZoom(100);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.addJavascriptInterface(new Bridge(), "Native");

        // Target 35 draws edge to edge: keep the page clear of the bars and keyboard.
        web.setOnApplyWindowInsetsListener((v, insets) -> {
            Insets i = insets.getInsets(WindowInsets.Type.systemBars()
                    | WindowInsets.Type.displayCutout() | WindowInsets.Type.ime());
            v.setPadding(i.left, 0, i.right, 0);
            float d = getResources().getDisplayMetrics().density;
            insetsJs = "document.documentElement.style.setProperty('--top','" + Math.round(i.top / d)
                    + "px');document.documentElement.style.setProperty('--bottom','"
                    + Math.round(i.bottom / d) + "px')";
            web.evaluateJavascript(insetsJs, null);
            return WindowInsets.CONSUMED;
        });
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                if (insetsJs != null) view.evaluateJavascript(insetsJs, null);
            }

            // A crashed page should reopen, not close the app (playback keeps going).
            @Override public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                recreate();
                return true;
            }
        });
        setContentView(web);
        applyBars();
        web.loadUrl("file:///android_asset/index.html");

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 9);
        }
    }

    private boolean isNight() {
        return (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
    }

    private void applyBars() {
        boolean night = isNight();
        int ground = Color.parseColor(night ? "#0E2A28" : "#D5E3DF");
        web.setBackgroundColor(ground);
        getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(ground));
        WindowInsetsController c = getWindow().getInsetsController();
        if (c != null) {
            int light = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                    | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
            c.setSystemBarsAppearance(night ? 0 : light, light);
        }
    }

    @Override public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        applyBars();
    }

    @Override protected void onResume() {
        super.onResume();
        handler.post(stateTick);
    }

    @Override protected void onPause() {
        handler.removeCallbacks(stateTick);
        super.onPause();
    }

    @Override public void onBackPressed() {
        // The page closes an open sheet first; otherwise leave, playback continues.
        web.evaluateJavascript("window.onBack&&window.onBack()", (ValueCallback<String>) v -> {
            if (!"true".equals(v)) moveTaskToBack(true);
        });
    }

    private void pushState() {
        try {
            String state = PlayerService.stateJson();
            if (state.equals(lastState)) return;
            lastState = state;
            web.evaluateJavascript("window.onState&&onState(" + state + ")", null);
        } catch (Exception ignored) {
            // Skip this tick.
        }
    }

    private void send(String action, String id) {
        Intent i = new Intent(this, PlayerService.class).setAction(action);
        if (id != null) i.putExtra(PlayerService.EXTRA_ID, id);
        startForegroundService(i);
    }

    private void callJs(String function, String json) {
        runOnUiThread(() -> web.evaluateJavascript("window." + function + "&&" + function + "(" + json + ")", null));
    }

    public final class Bridge {
        @JavascriptInterface public String getList() { return Store.json(); }

        @JavascriptInterface public void saveList(String json) {
            try {
                Store.save(json);
            } catch (Exception e) {
                return;
            }
            handler.post(() -> { if (PlayerService.instance != null) PlayerService.instance.listChanged(); });
        }

        @JavascriptInterface public void pickFiles() {
            startActivityForResult(openDocument(true), PICK_FILES);
        }

        @JavascriptInterface public void pickFolder() {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                            | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(i, PICK_FOLDER);
        }

        @JavascriptInterface public void pickReplacement(String id) {
            replaceId = id;
            startActivityForResult(openDocument(false), PICK_REPLACEMENT);
        }

        @JavascriptInterface public void playId(String id) { handler.post(() -> send(PlayerService.ACTION_PLAY_ID, id)); }
        @JavascriptInterface public void toggle() { handler.post(() -> send(PlayerService.ACTION_TOGGLE, null)); }
        @JavascriptInterface public void next() { handler.post(() -> send(PlayerService.ACTION_NEXT, null)); }
        @JavascriptInterface public void prev() { handler.post(() -> send(PlayerService.ACTION_PREV, null)); }

        @JavascriptInterface public void seek(double ms) {
            handler.post(() -> { if (PlayerService.instance != null) PlayerService.instance.seek((long) ms); });
        }
    }

    private Intent openDocument(boolean many) {
        return new Intent(Intent.ACTION_OPEN_DOCUMENT)
                .addCategory(Intent.CATEGORY_OPENABLE)
                .setType("*/*")
                .putExtra(Intent.EXTRA_MIME_TYPES, AUDIO_TYPES)
                .putExtra(Intent.EXTRA_ALLOW_MULTIPLE, many)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                        | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (result != RESULT_OK || data == null) return;
        callJs("onImportStart", "true");
        new Thread(() -> {
            try {
                if (request == PICK_REPLACEMENT) {
                    Uri uri = data.getData();
                    keep(uri);
                    JSONObject o = describe(uri, null, null);
                    callJs("onReplaced", JSONObject.quote(replaceId) + "," + o);
                    return;
                }
                JSONArray out = new JSONArray();
                if (request == PICK_FILES) {
                    for (Uri uri : picked(data)) {
                        keep(uri);
                        out.put(describe(uri, null, null));
                    }
                } else {
                    Uri tree = data.getData();
                    getContentResolver().takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    walk(tree, DocumentsContract.getTreeDocumentId(tree), out, 0);
                }
                callJs("onFiles", out.toString());
            } catch (Exception e) {
                callJs("onFiles", "[]");
            }
        }).start();
    }

    private static List<Uri> picked(Intent data) {
        List<Uri> uris = new ArrayList<>();
        ClipData clip = data.getClipData();
        if (clip != null) {
            for (int i = 0; i < clip.getItemCount(); i++) uris.add(clip.getItemAt(i).getUri());
        } else if (data.getData() != null) {
            uris.add(data.getData());
        }
        return uris;
    }

    private void keep(Uri uri) {
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (SecurityException ignored) {
            // Some providers grant only for this session; playback still works now.
        }
    }

    private void walk(Uri tree, String docId, JSONArray out, int depth) throws Exception {
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId);
        String[] cols = {DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE};
        ContentResolver cr = getContentResolver();
        try (Cursor c = cr.query(children, cols, null, null, null)) {
            while (c != null && c.moveToNext()) {
                String id = c.getString(0);
                String name = c.getString(1);
                String mime = c.getString(2);
                if (DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) {
                    if (depth < 4) walk(tree, id, out, depth + 1);
                } else if (isAudio(mime, name)) {
                    out.put(describe(DocumentsContract.buildDocumentUriUsingTree(tree, id), name, mime));
                }
            }
        }
    }

    private static boolean isAudio(String mime, String name) {
        if (mime != null && (mime.startsWith("audio/") || mime.equals("application/ogg"))) return true;
        String n = name == null ? "" : name.toLowerCase(Locale.ROOT);
        for (String ext : new String[]{".mp3", ".m4a", ".aac", ".wav", ".ogg", ".opus", ".flac", ".amr", ".wma", ".3gp"}) {
            if (n.endsWith(ext)) return true;
        }
        return false;
    }

    private JSONObject describe(Uri uri, String name, String ignoredMime) throws Exception {
        if (name == null) {
            try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                if (c != null && c.moveToFirst()) name = c.getString(0);
            }
        }
        long dur = 0;
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(this, uri);
            String d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            if (d != null) dur = Long.parseLong(d);
        } catch (Exception ignored) {
            // Unknown length: the player reports it once the file is played.
        } finally {
            try { r.release(); } catch (Exception ignored) { }
        }
        return new JSONObject().put("uri", uri.toString()).put("name", name == null ? "" : name).put("dur", dur);
    }
}
