package com.alrawais.sawtiyati;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

/** The ordered list (sorted by the UI) and the "where did I stop" bookmark. */
final class Store {
    private static JSONArray list;
    private static File file;
    private static SharedPreferences prefs;

    private Store() {}

    static synchronized void init(Context c) {
        if (list != null) return;
        Context app = c.getApplicationContext();
        file = new File(app.getFilesDir(), "list.json");
        prefs = app.getSharedPreferences("player", Context.MODE_PRIVATE);
        list = new JSONArray();
        if (file.exists()) {
            try (FileInputStream in = new FileInputStream(file)) {
                ByteArrayOutputStream all = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                for (int n; (n = in.read(buf)) > 0; ) all.write(buf, 0, n);
                list = new JSONArray(all.toString("UTF-8"));
            } catch (Exception ignored) {
                // Unreadable file: start empty rather than crash.
            }
        }
    }

    static synchronized String json() {
        return list.toString();
    }

    static synchronized void save(String json) throws JSONException {
        JSONArray parsed = new JSONArray(json);
        list = parsed;
        File tmp = new File(file.getPath() + ".tmp");
        try (FileOutputStream out = new FileOutputStream(tmp)) {
            out.write(json.getBytes(StandardCharsets.UTF_8));
            out.getFD().sync();
        } catch (Exception e) {
            return;
        }
        tmp.renameTo(file);
    }

    static synchronized JSONObject first() {
        return list.length() == 0 ? null : list.optJSONObject(0);
    }

    static synchronized JSONObject byId(String id) {
        int i = indexOf(id);
        return i < 0 ? null : list.optJSONObject(i);
    }

    /** Returns the item at (index of id + step), or null past either end. */
    static synchronized JSONObject neighbour(String id, int step) {
        int i = indexOf(id);
        if (i < 0) return null;
        int n = i + step;
        return n >= 0 && n < list.length() ? list.optJSONObject(n) : null;
    }

    private static int indexOf(String id) {
        if (id == null) return -1;
        for (int i = 0; i < list.length(); i++) {
            JSONObject o = list.optJSONObject(i);
            if (o != null && id.equals(o.optString("id"))) return i;
        }
        return -1;
    }

    static void bookmark(String id, long pos, int repDone) {
        prefs.edit().putString("id", id).putLong("pos", pos).putInt("rep", repDone).apply();
    }

    static String bookmarkId() { return prefs.getString("id", null); }
    static long bookmarkPos() { return prefs.getLong("pos", 0); }
    static int bookmarkRep() { return prefs.getInt("rep", 0); }
}
