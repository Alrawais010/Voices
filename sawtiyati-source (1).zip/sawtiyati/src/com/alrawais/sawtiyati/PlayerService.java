package com.alrawais.sawtiyati;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.MediaPlayer;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Plays the list in order. Each file plays `rep` times (no value means once),
 * then the next file starts. Runs as a foreground service so it keeps going
 * with the screen off.
 */
public class PlayerService extends Service {
    static final String ACTION_PLAY_ID = "play_id";
    static final String ACTION_TOGGLE = "toggle";
    static final String ACTION_NEXT = "next";
    static final String ACTION_PREV = "prev";
    static final String ACTION_STOP = "stop";
    static final String EXTRA_ID = "id";

    private static final String CHANNEL = "player";
    private static final int NOTIFICATION = 1;

    /** Only touched on the main thread. */
    static PlayerService instance;
    /** Set when a file fails, read once by the UI. */
    static volatile String failedId;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private MediaPlayer player;
    private boolean prepared;
    private String currentId;
    private String currentUri;
    private String currentTitle = "";
    private int repDone;
    private long pendingSeek;
    private boolean resumeAfterFocus;
    private boolean inForeground;
    private boolean noisyRegistered;

    private MediaSession session;
    private AudioManager audio;
    private AudioFocusRequest focus;
    private PowerManager.WakeLock wake;

    private final BroadcastReceiver noisy = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { pause(); }
    };

    private final Runnable bookmarkTick = new Runnable() {
        @Override public void run() {
            saveBookmark();
            handler.postDelayed(this, 5000);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        instance = this;
        Store.init(this);
        audio = getSystemService(AudioManager.class);
        wake = getSystemService(PowerManager.class)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "sawtiyati:play");
        wake.setReferenceCounted(false);

        AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build();
        focus = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(attrs)
                .setOnAudioFocusChangeListener(this::onFocus, handler).build();

        NotificationChannel ch = new NotificationChannel(CHANNEL,
                getString(R.string.channel), NotificationManager.IMPORTANCE_LOW);
        ch.setShowBadge(false);
        getSystemService(NotificationManager.class).createNotificationChannel(ch);

        session = new MediaSession(this, "sawtiyati");
        session.setCallback(new MediaSession.Callback() {
            @Override public void onPlay() { resume(); }
            @Override public void onPause() { pause(); }
            @Override public void onSkipToNext() { step(1, false); }
            @Override public void onSkipToPrevious() { step(-1, false); }
            @Override public void onSeekTo(long pos) { seek(pos); }
            @Override public void onStop() { shutdown(); }
        });
        session.setActive(true);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        // A foreground start must promote within seconds, whatever the command.
        showNotification(true);
        String action = intent == null ? null : intent.getAction();
        if (ACTION_PLAY_ID.equals(action)) {
            JSONObject item = Store.byId(intent.getStringExtra(EXTRA_ID));
            if (item != null) load(item, 0, 0);
            else shutdown();
        } else if (ACTION_TOGGLE.equals(action)) {
            toggle();
        } else if (ACTION_NEXT.equals(action)) {
            step(1, false);
        } else if (ACTION_PREV.equals(action)) {
            step(-1, false);
        } else {
            shutdown();
        }
        return START_NOT_STICKY;
    }

    private void toggle() {
        if (player != null && prepared && player.isPlaying()) pause();
        else if (player != null && prepared) resume();
        else if (player == null) resumeBookmarkOrFirst();
    }

    private void resumeBookmarkOrFirst() {
        JSONObject item = Store.byId(Store.bookmarkId());
        if (item != null) load(item, Store.bookmarkPos(), Store.bookmarkRep());
        else if ((item = Store.first()) != null) load(item, 0, 0);
        else shutdown();
    }

    private void load(JSONObject item, long startAt, int repAlreadyDone) {
        releasePlayer();
        currentId = item.optString("id");
        currentUri = item.optString("uri");
        currentTitle = label(item);
        repDone = repAlreadyDone;
        pendingSeek = startAt;
        wake.acquire();

        MediaPlayer mp = new MediaPlayer();
        player = mp;
        prepared = false;
        try {
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            mp.setOnPreparedListener(p -> { if (p == player) onPrepared(); });
            mp.setOnCompletionListener(p -> { if (p == player) onFinished(); });
            mp.setOnErrorListener((p, what, extra) -> {
                if (p == player) onFailed();
                return true;
            });
            mp.setDataSource(this, Uri.parse(currentUri));
            mp.prepareAsync();
        } catch (Exception e) {
            onFailed();
        }
    }

    private void onPrepared() {
        prepared = true;
        if (pendingSeek > 0 && pendingSeek < player.getDuration()) player.seekTo((int) pendingSeek);
        pendingSeek = 0;
        resume();
    }

    /** One pass of the current file ended: repeat it or move on. */
    private void onFinished() {
        repDone++;
        JSONObject item = Store.byId(currentId);
        int wanted = item == null ? 1 : Math.max(1, item.optInt("rep", 0));
        if (repDone < wanted) {
            player.seekTo(0);
            player.start();
            saveBookmark();
            publish();
        } else {
            step(1, true);
        }
    }

    private void onFailed() {
        failedId = currentId;
        step(1, true);
    }

    /** Moves by one file. At the end of the list playback stops. */
    private void step(int direction, boolean automatic) {
        JSONObject target = Store.neighbour(currentId, direction);
        if (currentId == null) {
            resumeBookmarkOrFirst();
        } else if (target != null) {
            load(target, 0, 0);
        } else if (automatic) {
            Store.bookmark(null, 0, 0);
            currentId = null;
            shutdown();
        } else if (player != null && prepared) {
            seek(0);
        }
    }

    private void resume() {
        if (player == null) { resumeBookmarkOrFirst(); return; }
        if (!prepared) return;
        if (audio.requestAudioFocus(focus) != AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
            afterStopped();
            publish();
            return;
        }
        resumeAfterFocus = false;
        wake.acquire();
        player.start();
        if (!noisyRegistered) {
            registerReceiver(noisy, new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY));
            noisyRegistered = true;
        }
        handler.removeCallbacks(bookmarkTick);
        handler.post(bookmarkTick);
        publish();
    }

    private void pause() {
        if (player == null || !prepared || !player.isPlaying()) return;
        player.pause();
        afterStopped();
        publish();
    }

    private void afterStopped() {
        handler.removeCallbacks(bookmarkTick);
        saveBookmark();
        if (noisyRegistered) {
            unregisterReceiver(noisy);
            noisyRegistered = false;
        }
        if (wake.isHeld()) wake.release();
    }

    void seek(long pos) {
        if (player != null && prepared) {
            player.seekTo((int) pos);
            saveBookmark();
            publish();
        } else {
            pendingSeek = pos;
        }
    }

    private void onFocus(int change) {
        if (change == AudioManager.AUDIOFOCUS_LOSS) {
            pause();
        } else if (change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
            boolean wasPlaying = player != null && prepared && player.isPlaying();
            pause();
            resumeAfterFocus = wasPlaying;
        } else if (change == AudioManager.AUDIOFOCUS_GAIN && resumeAfterFocus) {
            resume();
        }
    }

    /** The UI changed the list: stop if the file in play was deleted or swapped. */
    void listChanged() {
        if (currentId == null) return;
        JSONObject item = Store.byId(currentId);
        if (item == null || !currentUri.equals(item.optString("uri"))) {
            Store.bookmark(null, 0, 0);
            currentId = null;
            shutdown();
        } else {
            currentTitle = label(item);
            publish();
        }
    }

    private void saveBookmark() {
        if (currentId == null) return;
        long pos = player != null && prepared ? player.getCurrentPosition() : pendingSeek;
        Store.bookmark(currentId, pos, repDone);
    }

    private void releasePlayer() {
        if (player == null) return;
        MediaPlayer old = player;
        player = null;
        prepared = false;
        try { old.reset(); } catch (Exception ignored) { }
        old.release();
    }

    private void shutdown() {
        saveBookmark();
        afterStopped();
        releasePlayer();
        audio.abandonAudioFocusRequest(focus);
        session.setActive(false);
        stopForeground(STOP_FOREGROUND_REMOVE);
        inForeground = false;
        stopSelf();
    }

    @Override public void onTaskRemoved(Intent rootIntent) {
        if (player == null || !prepared || !player.isPlaying()) shutdown();
    }

    @Override public void onDestroy() {
        if (instance == this) instance = null;
        handler.removeCallbacksAndMessages(null);
        if (noisyRegistered) unregisterReceiver(noisy);
        releasePlayer();
        if (wake.isHeld()) wake.release();
        session.release();
        super.onDestroy();
    }

    private boolean isPlaying() {
        return player != null && prepared && player.isPlaying();
    }

    private void publish() {
        long dur = prepared ? player.getDuration() : 0;
        long pos = prepared ? player.getCurrentPosition() : 0;
        session.setMetadata(new MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, currentTitle)
                .putString(MediaMetadata.METADATA_KEY_ARTIST, getString(R.string.app_name))
                .putLong(MediaMetadata.METADATA_KEY_DURATION, dur).build());
        session.setPlaybackState(new PlaybackState.Builder()
                .setActions(PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE
                        | PlaybackState.ACTION_PLAY_PAUSE | PlaybackState.ACTION_SKIP_TO_NEXT
                        | PlaybackState.ACTION_SKIP_TO_PREVIOUS | PlaybackState.ACTION_SEEK_TO
                        | PlaybackState.ACTION_STOP)
                .setState(isPlaying() ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED,
                        pos, isPlaying() ? 1f : 0f).build());
        showNotification(isPlaying());
    }

    private void showNotification(boolean foreground) {
        Notification n = buildNotification(foreground);
        if (foreground) {
            startForeground(NOTIFICATION, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            inForeground = true;
        } else {
            if (inForeground) {
                stopForeground(STOP_FOREGROUND_DETACH);
                inForeground = false;
            }
            getSystemService(NotificationManager.class).notify(NOTIFICATION, n);
        }
    }

    private Notification buildNotification(boolean playing) {
        Intent open = new Intent(this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_note)
                .setContentTitle(currentTitle.isEmpty() ? getString(R.string.app_name) : currentTitle)
                .setContentIntent(PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE))
                .setDeleteIntent(action(ACTION_STOP))
                .setOngoing(playing)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setStyle(new Notification.MediaStyle()
                        .setMediaSession(session.getSessionToken())
                        .setShowActionsInCompactView(0, 1, 2))
                .addAction(button(R.drawable.ic_prev, R.string.prev, ACTION_PREV))
                .addAction(button(playing ? R.drawable.ic_pause : R.drawable.ic_play,
                        playing ? R.string.pause : R.string.play, ACTION_TOGGLE))
                .addAction(button(R.drawable.ic_next, R.string.next, ACTION_NEXT))
                .build();
    }

    private Notification.Action button(int icon, int label, String name) {
        return new Notification.Action.Builder(Icon.createWithResource(this, icon),
                getString(label), action(name)).build();
    }

    private PendingIntent action(String name) {
        Intent i = new Intent(this, PlayerService.class).setAction(name);
        return PendingIntent.getForegroundService(this, name.hashCode(), i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    /** "١.٤ عنوان" for the notification. */
    private static String label(JSONObject item) {
        StringBuilder out = new StringBuilder();
        for (char c : item.optString("num").toCharArray()) {
            out.append(c >= '0' && c <= '9' ? (char) ('٠' + (c - '0')) : c);
        }
        String title = item.optString("title").trim();
        return title.isEmpty() ? out.toString() : out + "  " + title;
    }

    /** Snapshot for the UI, valid with or without a running service. */
    static String stateJson() throws JSONException {
        JSONObject s = new JSONObject();
        PlayerService p = instance;
        String id;
        long pos;
        long dur = 0;
        int done;
        boolean playing = false;
        if (p != null && p.currentId != null) {
            id = p.currentId;
            done = p.repDone;
            boolean ready = p.player != null && p.prepared;
            pos = ready ? p.player.getCurrentPosition() : p.pendingSeek;
            dur = ready ? p.player.getDuration() : 0;
            playing = p.isPlaying();
        } else {
            id = Store.bookmarkId();
            pos = Store.bookmarkPos();
            done = Store.bookmarkRep();
        }
        JSONObject item = Store.byId(id);
        if (item == null) {
            s.put("id", JSONObject.NULL);
        } else {
            s.put("id", id);
            s.put("pos", pos);
            s.put("dur", dur > 0 ? dur : item.optLong("dur"));
            s.put("done", done);
            s.put("playing", playing);
        }
        String failed = failedId;
        if (failed != null) {
            failedId = null;
            s.put("failed", failed);
        }
        return s.toString();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
