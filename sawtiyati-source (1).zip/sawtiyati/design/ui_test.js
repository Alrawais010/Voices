// Drives the real page with a stand-in for the native bridge.
const { chromium } = require('playwright');
const path = require('path');
const assert = require('assert');
const OUT = process.argv[2];

const mock = () => {
  window.calls = [];
  window.saved = '[]';
  window.Native = {
    getList: () => window.saved,
    saveList: j => { window.saved = j; window.calls.push(['save']); },
    pickFiles() { calls.push(['pickFiles']); }, pickFolder() { calls.push(['pickFolder']); },
    pickReplacement(i) { calls.push(['replace', i]); },
    playId(i) { calls.push(['play', i]); }, toggle() { calls.push(['toggle']); },
    next() { calls.push(['next']); }, prev() { calls.push(['prev']); }, seek(m) { calls.push(['seek', m]); },
  };
};

(async () => {
  const b = await chromium.launch();
  for (const scheme of ['light', 'dark']) {
    const p = await b.newPage({ viewport: { width: 412, height: 900 }, deviceScaleFactor: 2, colorScheme: scheme });
    const errors = [];
    p.on('pageerror', e => errors.push(e.message));
    await p.addInitScript(mock);
    await p.goto('file://' + path.resolve('assets/index.html'));
    await p.evaluate(() => document.fonts.ready);

    if (scheme === 'light') await p.screenshot({ path: `${OUT}/empty.png` });

    await p.evaluate(() => onFiles([
      { uri: 'u/a', name: '2.1 قصة الوادي.mp3', dur: 754000 },
      { uri: 'u/b', name: '١.٤ مقدمة البرنامج.m4a', dur: 185000 },
      { uri: 'u/c', name: '1.10.mp3', dur: 61000 },
      { uri: 'u/d', name: '1.2-الدرس الأول في الحساب مع شرح طويل جدا يحتاج إلى سطرين على الأقل.mp3', dur: 3725000 },
      { uri: 'u/e', name: '10.mp3', dur: 90000 },
      { uri: 'u/f', name: 'AUD-20260101-WA0003.opus', dur: 12000 },
      { uri: 'u/g', name: '2024-05-01 لقاء.mp3', dur: 0 },
      { uri: 'u/h', name: '3.mp3', dur: 240000 },
    ]));
    const order = await p.$$eval('.num', els => els.map(e => e.textContent));
    assert.deepStrictEqual(order, ['١.٢', '١.٤', '١.١٠', '٢.١', '٣', '١٠', '١١', '١٢'], 'order: ' + order);

    // Repeat editing
    await p.click('.item:nth-child(2) .rep');
    await p.click('#repPlus'); await p.click('#repPlus'); await p.click('#repPlus');
    assert.equal(await p.inputValue('#fRep'), '٣');
    await p.fill('#fNum', 'خطأ'); await p.click('#saveBtn');
    assert.ok((await p.textContent('#numErr')).includes('١.٤'));
    await p.fill('#fNum', '٢٫٥'); await p.fill('#fTitle', 'عنوان جديد'); await p.click('#saveBtn');
    const order2 = await p.$$eval('.num', els => els.map(e => e.textContent));
    assert.deepStrictEqual(order2, ['١.٢', '١.١٠', '٢.١', '٢.٥', '٣', '١٠', '١١', '١٢'], 'after edit: ' + order2);

    // A blank repeat stays "not set"
    await p.click('.item:nth-child(4) .rep');
    await p.fill('#fRep', ''); await p.click('#saveBtn');
    assert.equal(JSON.parse(await p.evaluate(() => saved)).find(i => i.num === '2.5').rep, 0);
    await p.click('.item:nth-child(4) .rep');
    await p.fill('#fRep', '3'); await p.click('#saveBtn');

    // Delete, keeping the list sorted
    await p.click('.item:nth-child(1) .rep'); await p.click('#deleteBtn'); await p.click('#delYes');
    assert.equal(await p.$$eval('.item', e => e.length), 7);
    await p.evaluate(() => onFiles([{ uri: 'u/d', name: '1.2 الدرس الأول.mp3', dur: 3725000 }]));
    await p.evaluate(() => onFiles([{ uri: 'u/d', name: '1.2 الدرس الأول.mp3', dur: 3725000 }]));
    assert.equal(await p.$$eval('.item', e => e.length), 8);

    // Play: bar shows, tapping sends the id, repeat counter follows state
    await p.click('.item:nth-child(4) .body');
    const call = await p.evaluate(() => calls.filter(c => c[0] === 'play').pop());
    const id = JSON.parse(await p.evaluate(() => saved)).find(i => i.num === '2.5').id;
    assert.equal(call[1], id);
    await p.evaluate(i => onState({ id: i, pos: 92000, dur: 185000, done: 1, playing: true }), id);
    assert.ok((await p.textContent('#nowTitle')).includes('(٢ من ٣)'));
    assert.equal(await p.textContent('.item.now .rep b'), '٢');
    await p.waitForTimeout(100);
    await p.screenshot({ path: `${OUT}/list-${scheme}.png` });

    await p.click('.item.now .rep');
    await p.screenshot({ path: `${OUT}/edit-${scheme}.png` });
    assert.equal(await p.evaluate(() => onBack()), true);
    assert.equal(await p.evaluate(() => onBack()), false);

    await p.evaluate(i => onState({ id: i, pos: 0, dur: 185000, done: 0, playing: false, failed: i }), id);
    assert.ok((await p.textContent('.item.now')).includes('تعذر'));
    await p.evaluate(() => onState({ id: null }));
    assert.equal(await p.isVisible('#player'), false);
    assert.equal(await p.$$eval('.item.now', e => e.length), 0);

    // Survives a reopen, 100 files stay quick
    const saved = await p.evaluate(() => saved);
    await p.addInitScript(s => { window.saved = s; }, saved);
    await p.reload();
    assert.equal(await p.$$eval('.item', e => e.length), 8);
    await p.evaluate(() => onFiles(Array.from({ length: 100 }, (_, i) => ({ uri: 'x/' + i, name: `${Math.floor(i / 10) + 20}.${i % 10 + 1} درس.mp3`, dur: 60000 + i * 1000 }))));
    assert.equal(await p.$$eval('.item', e => e.length), 108);
    assert.equal(await p.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true);
    assert.deepStrictEqual(errors, []);
    await p.close();
  }

  // Unfolded screen
  const p = await b.newPage({ viewport: { width: 880, height: 1000 }, deviceScaleFactor: 1 });
  await p.addInitScript(mock);
  await p.goto('file://' + path.resolve('assets/index.html'));
  await p.evaluate(() => onFiles([{ uri: 'a', name: '1.4 مقدمة.mp3', dur: 90000 }, { uri: 'b', name: '2.1.mp3', dur: 3000 }]));
  await p.screenshot({ path: `${OUT}/unfolded.png` });
  await b.close();
  console.log('UI OK');
})().catch(e => { console.error(e); process.exit(1); });
