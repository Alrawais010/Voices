const {chromium}=require('playwright');const fs=require('fs');
(async()=>{const b=await chromium.launch();
const svg=fs.readFileSync('design/icon.svg','utf8');
const sizes={mdpi:[108,48],hdpi:[162,72],xhdpi:[216,96],xxhdpi:[324,144],xxxhdpi:[432,192]};
for(const[d,[fg,leg]]of Object.entries(sizes)){
 fs.mkdirSync(`res/mipmap-${d}`,{recursive:true});
 for(const[name,px,bg,rad]of[['ic_fg',fg,'transparent',0],['ic_launcher',leg,'#0F5C57',.5]]){
  const p=await b.newPage({viewport:{width:px,height:px}});
  const inner=name==='ic_launcher'?1.45:1;
  await p.setContent(`<body style="margin:0;background:transparent"><div style="width:${px}px;height:${px}px;background:${bg};border-radius:${rad*100}%;overflow:hidden;display:flex;align-items:center;justify-content:center"><div style="width:${px*inner}px;height:${px*inner}px;flex:none">${svg}</div></div>`);
  await p.screenshot({path:`res/mipmap-${d}/${name}.png`,omitBackground:true});await p.close();}}
await b.close()})();
