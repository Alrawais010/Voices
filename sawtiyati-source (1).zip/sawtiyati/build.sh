#!/bin/bash
# Builds the signed APK with the plain Android build tools (no Gradle).
set -e
cd "$(dirname "$0")"
SDK=${ANDROID_SDK:-/root/sdk}; BT=$(echo $SDK/build-tools/*); JAR=$SDK/platforms/android-35/android.jar
rm -rf build; mkdir -p build/res build/gen build/classes build/dex
"$BT/aapt2" compile --dir res -o build/res/res.zip
"$BT/aapt2" link -o build/base.apk -I "$JAR" --manifest AndroidManifest.xml -A assets \
  --java build/gen --min-sdk-version 30 --target-sdk-version 35 --auto-add-overlay build/res/res.zip
javac -nowarn -source 11 -target 11 -classpath "$JAR" -d build/classes \
  $(find src build/gen -name '*.java') 2>&1 | grep -v -E 'JAVA_TOOL|^Note|bootstrap|obsolete|suppress' || true
"$BT/d8" --release --lib "$JAR" --min-api 30 --output build/dex $(find build/classes -name '*.class')
cp build/base.apk build/app.apk
(cd build/dex && zip -q ../app.apk classes.dex)
"$BT/zipalign" -f -p 4 build/app.apk build/aligned.apk
"$BT/apksigner" sign --ks sawtiyati.jks --ks-pass pass:sawtiyati --key-pass pass:sawtiyati --out sawtiyati.apk build/aligned.apk
"$BT/apksigner" verify sawtiyati.apk && ls -la sawtiyati.apk
