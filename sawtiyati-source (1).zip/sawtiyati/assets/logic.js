/* Pure list rules: numbers, ordering, reading file names. No page access. */
(function (root) {
  const AR = '٠١٢٣٤٥٦٧٨٩', FA = '۰۱۲۳۴۵۶۷۸۹';

  function toLatin(s) {
    return String(s).replace(/[٠-٩۰-۹]/g, c => {
      const i = AR.indexOf(c);
      return String(i >= 0 ? i : FA.indexOf(c));
    });
  }

  function toArabic(v) {
    return String(v).replace(/\d/g, d => AR[+d]);
  }

  /* "٠١٫٠٤" → "1.4". Returns null when it is not a number like ١ or ١.٤ */
  function cleanNumber(s) {
    const t = toLatin(s).trim().replace(/[٫,،\-_\/\s]+/g, '.');
    if (!/^\d+(\.\d+)*$/.test(t)) return null;
    return t.split('.').map(p => String(parseInt(p, 10))).join('.');
  }

  /* Each part is compared on its own: ١.٤ < ١.١٠ < ٢.١, and ٢ < ٢.١ */
  function compareNumbers(a, b) {
    const x = a.split('.').map(Number), y = b.split('.').map(Number);
    for (let i = 0; i < Math.max(x.length, y.length); i++) {
      if (i >= x.length) return -1;
      if (i >= y.length) return 1;
      if (x[i] !== y[i]) return x[i] - y[i];
    }
    return 0;
  }

  function sortItems(items) {
    return items.slice().sort((a, b) => compareNumbers(a.num, b.num) || a.added - b.added);
  }

  /* "1.4 الفاتحة.mp3" → {num:"1.4", title:"الفاتحة"}. A name that does not
     start with a number keeps its whole text as the title and gets num:null.
     Dates such as 2024-05-01 are not file numbers. */
  function readName(name) {
    const base = toLatin(String(name).replace(/\.[^.\s]{1,5}$/, '')).trim();
    const m = base.match(/^(\d{1,3}(?:[.\-_٫]\d+)*)(?![\d])(.*)$/);
    if (!m) return { num: null, title: base };
    return { num: cleanNumber(m[1]), title: m[2].replace(/^[\s.\-_–—)]+/, '').trim() };
  }

  /* The next free whole number after the list's highest. */
  function nextNumber(items) {
    return String(items.reduce((max, it) => Math.max(max, parseInt(it.num, 10) || 0), 0) + 1);
  }

  /* 65000 → "١:٠٥", 3725000 → "١:٠٢:٠٥" */
  function clock(ms) {
    const t = Math.round((ms || 0) / 1000), h = Math.floor(t / 3600), m = Math.floor(t / 60) % 60, s = t % 60;
    const pad = n => String(n).padStart(2, '0');
    return toArabic(h ? `${h}:${pad(m)}:${pad(s)}` : `${m}:${pad(s)}`);
  }

  /* 19260000 → "٥ ساعات و٢١ دقيقة" */
  function longTime(ms) {
    const mins = Math.round((ms || 0) / 60000), h = Math.floor(mins / 60), m = mins % 60;
    const hours = h === 0 ? '' : h === 1 ? 'ساعة' : h === 2 ? 'ساعتان' : h <= 10 ? `${toArabic(h)} ساعات` : `${toArabic(h)} ساعة`;
    const minutes = m === 0 ? '' : m === 1 ? 'دقيقة' : m === 2 ? 'دقيقتان' : m <= 10 ? `${toArabic(m)} دقائق` : `${toArabic(m)} دقيقة`;
    return [hours, minutes].filter(Boolean).join(' و') || 'أقل من دقيقة';
  }

  function countFiles(n) {
    if (n === 1) return 'ملف واحد';
    if (n === 2) return 'ملفان';
    return n >= 3 && n <= 10 ? `${toArabic(n)} ملفات` : `${toArabic(n)} ملف`;
  }

  root.Logic = { toLatin, toArabic, cleanNumber, compareNumbers, sortItems, readName, nextNumber, clock, longTime, countFiles };
})(typeof window !== 'undefined' ? window : globalThis);
