/* Screen: list of rectangles, edit sheets, player bar. Playback lives in the native service. */
(function () {
  const { toLatin, toArabic, cleanNumber, sortItems, readName, nextNumber, clock, longTime, countFiles } = Logic;
  const $ = id => document.getElementById(id);
  const PLAY = 'M18 12 7 5v14z', PAUSE = 'M6 5h4.5v14H6zM13.5 5H18v14h-4.5z';

  let items = [];
  try { items = JSON.parse(Native.getList()) || []; } catch (e) { items = []; }

  let state = { id: null };
  let editing = null;      /* item open in the edit sheet */
  let draftFile = null;    /* {uri,name,dur} chosen in the sheet, not saved yet */
  let seeking = false;
  const broken = new Set();

  const newId = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  const byId = id => items.find(it => it.id === id);

  function commit() {
    items = sortItems(items);
    Native.saveList(JSON.stringify(items));
    render();
  }

  function card(it) {
    const li = document.createElement('li');
    li.className = 'item';
    li.dataset.id = it.id;

    const tape = document.createElement('div');
    tape.className = 'tape';

    const num = document.createElement('button');
    num.className = 'num' + (it.num.length > 5 ? ' long' : '');
    num.textContent = toArabic(it.num);
    num.setAttribute('aria-label', 'تشغيل ' + toArabic(it.num));
    num.dataset.act = 'play';

    const body = document.createElement('button');
    body.className = 'body';
    body.dataset.act = 'play';
    const title = document.createElement('div');
    title.className = 'title' + (it.title ? '' : ' none');
    title.textContent = it.title || 'بدون عنوان';
    const dur = document.createElement('div');
    dur.className = 'dur';
    dur.textContent = it.dur ? clock(it.dur) : 'المدة غير معروفة';
    body.append(title, dur);
    if (broken.has(it.id)) {
      const w = document.createElement('div');
      w.className = 'warn';
      w.textContent = 'تعذر تشغيل الملف، غيّره من التحرير';
      body.append(w);
    }

    const rep = document.createElement('button');
    rep.className = 'rep';
    rep.dataset.act = 'edit';
    rep.setAttribute('aria-label', 'تحرير الملف ' + toArabic(it.num));
    fillRep(rep, it, false);

    li.append(tape, num, body, rep);
    return li;
  }

  function fillRep(el, it, playing) {
    const wanted = it.rep || 0;
    if (playing && wanted > 1) {
      el.innerHTML = '<b></b><span></span>';
      el.firstChild.textContent = toArabic(Math.min((state.done || 0) + 1, wanted));
      el.lastChild.textContent = 'من ' + toArabic(wanted);
    } else if (wanted) {
      el.innerHTML = '<b></b><span>تكرار</span>';
      el.firstChild.textContent = toArabic(wanted);
    } else {
      el.textContent = 'تحرير';
    }
  }

  function render() {
    const list = $('list');
    list.replaceChildren(...items.map(card));
    $('empty').style.display = items.length ? 'none' : 'block';
    $('summary').textContent = items.length
      ? countFiles(items.length) + '، ' + longTime(items.reduce((t, it) => t + (it.dur || 0), 0))
      : '';
    paintState(true);
  }

  /* Live part: only the rectangle in play and the bar change. */
  let shownId = null;
  function paintState(force) {
    const it = byId(state.id);
    if (force || shownId !== state.id) {
      const old = document.querySelector('.item.now');
      if (old) {
        old.classList.remove('now');
        old.querySelector('.tape').style.width = 0;
        const oldItem = byId(old.dataset.id);
        if (oldItem) fillRep(old.querySelector('.rep'), oldItem, false);
      }
      shownId = state.id;
      if (it) {
        const el = cardOf(it.id);
        if (el) {
          el.classList.add('now');
          if (!force) el.scrollIntoView({ block: 'nearest' });
        }
      }
    }
    $('player').hidden = !it;
    if (!it) return;

    const el = cardOf(it.id);
    const dur = state.dur || it.dur || 0, pos = Math.min(state.pos || 0, dur || 0);
    if (el) {
      el.querySelector('.tape').style.width = dur ? (pos / dur * 100) + '%' : 0;
      fillRep(el.querySelector('.rep'), it, true);
    }
    $('nowTitle').textContent = toArabic(it.num) + (it.title ? '  ' + it.title : '') + repeatNote(it);
    $('tPos').textContent = clock(pos);
    $('tDur').textContent = clock(dur);
    if (!seeking) $('seek').value = dur ? Math.round(pos / dur * 1000) : 0;
    $('playIcon').setAttribute('d', state.playing ? PAUSE : PLAY);
    $('playBtn').setAttribute('aria-label', state.playing ? 'إيقاف مؤقت' : 'تشغيل');
  }

  const cardOf = id => document.querySelector(`.item[data-id="${id}"]`);

  function repeatNote(it) {
    if (!it.rep || it.rep < 2) return '';
    return `  (${toArabic(Math.min((state.done || 0) + 1, it.rep))} من ${toArabic(it.rep)})`;
  }

  /* ---- native events ---- */
  window.onState = s => {
    state = s;
    if (s.failed) {
      broken.add(s.failed);
      toast('تعذر تشغيل ملف، انتقلت إلى الذي بعده');
      render();
    } else {
      paintState(false);
    }
  };

  window.onImportStart = () => toast('جاري قراءة الملفات…', true);

  window.onFiles = files => {
    const known = new Set(items.map(it => it.uri));
    const stamp = Date.now();
    let added = 0;
    const fresh = files.filter(f => !known.has(f.uri));
    /* Numbered names first, so unnumbered ones continue after the highest number. */
    const read = fresh.map(f => ({ f, r: readName(f.name) }));
    read.sort((a, b) => (a.r.num === null) - (b.r.num === null));
    read.forEach(({ f, r }) => {
      items.push({
        id: newId(), num: r.num || nextNumber(items), title: r.title,
        rep: 0, uri: f.uri, name: f.name, dur: f.dur, added: stamp + added
      });
      added++;
    });
    if (added) commit();
    const skipped = files.length - added;
    if (!files.length) toast('لم يُعثر على ملفات صوتية');
    else if (!added) toast('هذه الملفات موجودة في القائمة');
    else toast('تمت إضافة ' + countFiles(added) + (skipped ? '، وتم تخطي المكرر' : ''));
  };

  window.onReplaced = (id, file) => {
    toast('');
    if (editing && editing.id === id) {
      draftFile = file;
      $('fFile').textContent = file.name;
    }
  };

  window.onBack = () => {
    const open = document.querySelector('.veil.open');
    if (open) { close(open); return true; }
    return false;
  };

  /* ---- list taps ---- */
  $('list').addEventListener('click', e => {
    const btn = e.target.closest('[data-act]');
    if (!btn) return;
    const it = byId(btn.closest('.item').dataset.id);
    if (!it) return;
    if (btn.dataset.act === 'edit') { openEdit(it); return; }
    if (it.id === state.id) Native.toggle();
    else { broken.delete(it.id); Native.playId(it.id); }
  });

  /* ---- sheets ---- */
  const open = id => $(id).classList.add('open');
  const close = el => el.classList.remove('open');
  document.querySelectorAll('[data-close]').forEach(b =>
    b.addEventListener('click', () => close(b.closest('.veil'))));
  document.querySelectorAll('.veil').forEach(v =>
    v.addEventListener('click', e => { if (e.target === v) close(v); }));

  $('addBtn').onclick = () => open('addVeil');
  $('addFiles').onclick = () => { close($('addVeil')); Native.pickFiles(); };
  $('addFolder').onclick = () => { close($('addVeil')); Native.pickFolder(); };

  function openEdit(it) {
    editing = it;
    draftFile = null;
    $('fNum').value = toArabic(it.num);
    $('fTitle').value = it.title || '';
    $('fRep').value = it.rep ? toArabic(it.rep) : '';
    $('numErr').textContent = '';
    $('fFile').textContent = it.name || '';
    open('editVeil');
  }

  function readRep() {
    const n = parseInt(toLatin($('fRep').value).replace(/\D/g, ''), 10);
    return n > 0 ? Math.min(n, 999) : 0;
  }
  function stepRep(by) {
    const n = Math.max(0, readRep() + by);
    $('fRep').value = n ? toArabic(n) : '';
  }
  $('repPlus').onclick = () => stepRep(1);
  $('repMinus').onclick = () => stepRep(-1);
  $('replaceBtn').onclick = () => Native.pickReplacement(editing.id);

  $('saveBtn').onclick = () => {
    const num = cleanNumber($('fNum').value);
    if (!num) {
      $('numErr').textContent = 'اكتب الرقم بهذا الشكل: ١.٤';
      return;
    }
    const fields = { num, title: $('fTitle').value.trim(), rep: readRep() };
    if (draftFile) Object.assign(fields, { uri: draftFile.uri, name: draftFile.name, dur: draftFile.dur });
    Object.assign(byId(editing.id), fields);
    broken.delete(editing.id);
    close($('editVeil'));
    commit();
    scrollToNumber(fields.num);
  };

  function scrollToNumber(num) {
    const it = items.find(x => x.num === num);
    const el = it && cardOf(it.id);
    if (el) el.scrollIntoView({ block: 'nearest' });
  }

  $('deleteBtn').onclick = () => {
    $('delHead').textContent = 'حذف الملف ' + toArabic(editing.num) + '؟';
    open('delVeil');
  };
  $('delYes').onclick = () => {
    items = items.filter(it => it.id !== editing.id);
    close($('delVeil'));
    close($('editVeil'));
    commit();
  };

  /* ---- player bar ---- */
  $('playBtn').onclick = () => Native.toggle();
  $('nextBtn').onclick = () => Native.next();
  $('prevBtn').onclick = () => Native.prev();
  $('seek').oninput = () => {
    seeking = true;
    const it = byId(state.id), dur = state.dur || (it && it.dur) || 0;
    $('tPos').textContent = clock(dur * $('seek').value / 1000);
  };
  $('seek').onchange = () => {
    const it = byId(state.id), dur = state.dur || (it && it.dur) || 0;
    Native.seek(dur * $('seek').value / 1000);
    seeking = false;
  };

  let toastTimer;
  function toast(text, stay) {
    const t = $('toast');
    clearTimeout(toastTimer);
    t.textContent = text;
    t.classList.toggle('show', !!text);
    if (text && !stay) toastTimer = setTimeout(() => t.classList.remove('show'), 3000);
  }

  items = sortItems(items);
  render();
})();
